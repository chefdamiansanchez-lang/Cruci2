package com.crucigramas.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class Saved(val letters: String, val seconds: Int, val done: Boolean)

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("crucigramas", Context.MODE_PRIVATE)

    fun load(key: String): Saved? {
        val s = sp.getString(key, null) ?: return null
        val parts = s.split("|")
        if (parts.size < 3) return null
        return Saved(parts[0], parts[1].toIntOrNull() ?: 0, parts[2] == "1")
    }

    fun save(key: String, letters: String, seconds: Int, done: Boolean) {
        sp.edit().putString(key, letters + "|" + seconds + "|" + (if (done) "1" else "0")).apply()
    }
}

fun storeKey(day: Long, level: Int): String = "g_" + day + "_" + level

fun todayNumber(): Long {
    val now = System.currentTimeMillis()
    return (now + TimeZone.getDefault().getOffset(now)) / 86400000L
}

fun dayLabel(day: Long): String {
    val sdf = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "ES"))
    sdf.timeZone = TimeZone.getTimeZone("UTC")
    return sdf.format(Date(day * 86400000L)).replaceFirstChar { it.uppercase() }
}
