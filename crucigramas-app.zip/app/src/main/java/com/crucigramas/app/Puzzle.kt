package com.crucigramas.app

import kotlin.random.Random

class Entry(val word: String, val clue: String, val r: Int, val c: Int, val across: Boolean) {
    var num = 0

    fun cells(): List<Pair<Int, Int>> =
        List(word.length) { k -> if (across) Pair(r, c + k) else Pair(r + k, c) }

    fun contains(rr: Int, cc: Int): Boolean =
        if (across) rr == r && cc >= c && cc < c + word.length
        else cc == c && rr >= r && rr < r + word.length
}

class Puzzle(val rows: Int, val cols: Int, val entries: List<Entry>) {
    val solution = Array(rows) { CharArray(cols) { '.' } }
    val numbers = Array(rows) { IntArray(cols) }

    init {
        for (e in entries) {
            var i = 0
            for (cell in e.cells()) {
                solution[cell.first][cell.second] = e.word[i]
                i++
            }
        }
        var n = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val starts = entries.filter { it.r == r && it.c == c }
                if (starts.isNotEmpty()) {
                    n++
                    starts.forEach { it.num = n }
                    numbers[r][c] = n
                }
            }
        }
    }

    fun entryAt(r: Int, c: Int, across: Boolean): Entry? =
        entries.firstOrNull { it.across == across && it.contains(r, c) }

    fun ordered(): List<Entry> =
        entries.filter { it.across }.sortedBy { it.num } +
            entries.filter { !it.across }.sortedBy { it.num }
}

class Level(val name: String, val desc: String, val size: Int, val target: Int, val maxLen: Int)

object Generator {
    val LEVELS = listOf(
        Level("Fácil", "Cuadrícula chica · palabras cortas", 9, 6, 6),
        Level("Normal", "Tamaño medio · más cruces", 10, 9, 7),
        Level("Difícil", "Cuadrícula grande · muchas pistas", 12, 13, 8)
    )

    private class Board(val n: Int) {
        val grid = Array(n) { CharArray(n) { '.' } }
        val acrossMark = Array(n) { BooleanArray(n) }
        val downMark = Array(n) { BooleanArray(n) }
        val placed = ArrayList<Entry>()

        fun empty(r: Int, c: Int): Boolean =
            r < 0 || c < 0 || r >= n || c >= n || grid[r][c] == '.'

        fun canPlace(word: String, r: Int, c: Int, isAcross: Boolean): Boolean {
            val dr = if (isAcross) 0 else 1
            val dc = if (isAcross) 1 else 0
            val er = r + dr * (word.length - 1)
            val ec = c + dc * (word.length - 1)
            if (r < 0 || c < 0 || er >= n || ec >= n) return false
            if (!empty(r - dr, c - dc) || !empty(er + dr, ec + dc)) return false
            var cross = 0
            for (k in word.indices) {
                val rr = r + dr * k
                val cc = c + dc * k
                val ch = grid[rr][cc]
                if (ch != '.') {
                    if (ch != word[k]) return false
                    val same = if (isAcross) acrossMark[rr][cc] else downMark[rr][cc]
                    if (same) return false
                    cross++
                } else {
                    if (!empty(rr + dc, cc + dr) || !empty(rr - dc, cc - dr)) return false
                }
            }
            return cross >= 1 && cross < word.length
        }

        fun place(word: String, clue: String, r: Int, c: Int, isAcross: Boolean) {
            val dr = if (isAcross) 0 else 1
            val dc = if (isAcross) 1 else 0
            for (k in word.indices) {
                val rr = r + dr * k
                val cc = c + dc * k
                grid[rr][cc] = word[k]
                if (isAcross) acrossMark[rr][cc] = true else downMark[rr][cc] = true
            }
            placed.add(Entry(word, clue, r, c, isAcross))
        }
    }

    fun generate(day: Long, level: Int): Puzzle {
        val lv = LEVELS[level]
        var best: Puzzle? = null
        for (attempt in 0 until 40) {
            val rnd = Random(day * 1000L + level * 100L + attempt)
            val p = build(lv, rnd)
            val b = best
            if (b == null || p.entries.size > b.entries.size) best = p
            if (p.entries.size >= lv.target) break
        }
        return best!!
    }

    private fun build(lv: Level, rnd: Random): Puzzle {
        val n = lv.size
        val board = Board(n)
        val pool = WORDS.filter { it.first.length in 3..lv.maxLen }.shuffled(rnd)
        val used = HashSet<String>()

        val first = pool.take(8).maxByOrNull { it.first.length }!!
        board.place(first.first, first.second, n / 2, (n - first.first.length) / 2, true)
        used.add(first.first)

        for (pass in 0 until 3) {
            for (w in pool) {
                if (board.placed.size >= lv.target) break
                val word = w.first
                if (word in used) continue
                val cands = ArrayList<IntArray>()
                for (r in 0 until n) {
                    for (c in 0 until n) {
                        val ch = board.grid[r][c]
                        if (ch == '.') continue
                        for (i in word.indices) {
                            if (word[i] != ch) continue
                            if (board.canPlace(word, r, c - i, true)) cands.add(intArrayOf(r, c - i, 1))
                            if (board.canPlace(word, r - i, c, false)) cands.add(intArrayOf(r - i, c, 0))
                        }
                    }
                }
                if (cands.isNotEmpty()) {
                    val pick = cands[rnd.nextInt(cands.size)]
                    board.place(word, w.second, pick[0], pick[1], pick[2] == 1)
                    used.add(word)
                }
            }
            if (board.placed.size >= lv.target) break
        }

        val placed = board.placed
        val minR = placed.minOf { it.r }
        val minC = placed.minOf { it.c }
        val maxR = placed.maxOf { if (it.across) it.r else it.r + it.word.length - 1 }
        val maxC = placed.maxOf { if (it.across) it.c + it.word.length - 1 else it.c }
        val shifted = placed.map { Entry(it.word, it.clue, it.r - minR, it.c - minC, it.across) }
        return Puzzle(maxR - minR + 1, maxC - minC + 1, shifted)
    }
}
