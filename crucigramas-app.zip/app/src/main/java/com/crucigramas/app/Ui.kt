package com.crucigramas.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

object C {
    val bgTop = Color(0xFFDCEBFB)
    val bgBottom = Color(0xFFF1F7FE)
    val primary = Color(0xFF2F6FD0)
    val navy = Color(0xFF1F3A5F)
    val word = Color(0xFFC8DFFA)
    val sel = Color(0xFFFFD36B)
    val wrong = Color(0xFFFFB9A8)
    val mint = Color(0xFF3FBF9B)
    val coral = Color(0xFFFF8A5B)
    val amber = Color(0xFFFFC857)
    val line = Color(0xFF9DBDE6)
}

fun fmt(s: Int): String = "%02d:%02d".format(s / 60, s % 60)

@Composable
fun App(store: Store) {
    val today = remember { todayNumber() }
    var day by remember { mutableStateOf(today) }
    var level by remember { mutableStateOf(-1) }
    var refresh by remember { mutableStateOf(0) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(C.bgTop, C.bgBottom)))
    ) {
        if (level < 0) {
            Home(day, today, store, refresh, { day = it }, { level = it })
        } else {
            Game(day, level, store) {
                level = -1
                refresh++
            }
        }
    }
}

@Composable
fun RoundBtn(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .shadow(2.dp, CircleShape)
            .clip(CircleShape)
            .background(if (enabled) Color.White else Color(0x66FFFFFF))
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = if (enabled) C.primary else C.line
        )
    }
}

@Composable
fun Pill(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(40.dp)
            .shadow(2.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .clickable { onClick() }
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun Home(
    day: Long,
    today: Long,
    store: Store,
    refresh: Int,
    onDay: (Long) -> Unit,
    onOpen: (Int) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Crucigramas", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = C.navy)
        Text("Un reto nuevo cada día", fontSize = 15.sp, color = C.primary)
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            RoundBtn("‹", day > today - 30) { onDay(day - 1) }
            Text(
                dayLabel(day),
                Modifier.weight(1f),
                textAlign = TextAlign.Center,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                color = C.navy
            )
            RoundBtn("›", day < today) { onDay(day + 1) }
        }
        Spacer(Modifier.height(18.dp))
        for (i in Generator.LEVELS.indices) {
            LevelCard(day, i, store, refresh) { onOpen(i) }
            Spacer(Modifier.height(14.dp))
        }
    }
}

@Composable
fun LevelCard(day: Long, i: Int, store: Store, refresh: Int, onOpen: () -> Unit) {
    val lv = Generator.LEVELS[i]
    val saved = remember(day, i, refresh) { store.load(storeKey(day, i)) }
    val done = saved != null && saved.done
    val status = if (saved == null) "Nuevo"
    else if (saved.done) "Completado · " + fmt(saved.seconds)
    else if (saved.letters.any { it != '.' }) "En progreso · " + fmt(saved.seconds)
    else "Nuevo"
    val accent = listOf(C.mint, C.primary, C.coral)[i]
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(3.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .clickable { onOpen() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(accent),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (done) "✓" else (i + 1).toString(),
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            Text(lv.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.navy)
            Text(lv.desc, fontSize = 13.sp, color = Color(0xFF6C86A8))
            Text(status, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = accent)
        }
        Text("›", fontSize = 28.sp, color = C.line)
    }
}

@Composable
fun CellView(size: Dp, sol: Char, ch: Char, num: Int, bg: Color, onClick: () -> Unit) {
    if (sol == '.') {
        Spacer(Modifier.size(size))
        return
    }
    Box(
        Modifier
            .size(size)
            .padding(1.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(1.dp, C.line, RoundedCornerShape(6.dp))
            .clickable { onClick() }
    ) {
        if (num > 0) {
            Text(
                num.toString(),
                fontSize = (size.value * 0.27f).sp,
                color = C.primary,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 2.dp)
            )
        }
        if (ch != '.') {
            Text(
                ch.toString(),
                fontSize = (size.value * 0.55f).sp,
                fontWeight = FontWeight.Bold,
                color = C.navy,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@Composable
fun Key(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(44.dp)
            .shadow(2.dp, RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = C.navy)
    }
}

@Composable
fun Game(day: Long, level: Int, store: Store, onBack: () -> Unit) {
    val puzzle = remember(day, level) { Generator.generate(day, level) }
    val key = storeKey(day, level)
    val cols = puzzle.cols
    val total = puzzle.rows * cols
    val ordered = remember(puzzle) { puzzle.ordered() }
    val saved = remember(key) { store.load(key)?.takeIf { it.letters.length == total } }
    val letters = remember(key) {
        val s = saved?.letters ?: ".".repeat(total)
        mutableStateListOf<Char>().also { l -> s.forEach { l.add(it) } }
    }
    val wrong = remember(key) { mutableStateListOf<Int>() }
    var seconds by remember(key) { mutableStateOf(saved?.seconds ?: 0) }
    var done by remember(key) { mutableStateOf(saved?.done ?: false) }
    var selR by remember(key) { mutableStateOf(ordered[0].r) }
    var selC by remember(key) { mutableStateOf(ordered[0].c) }
    var across by remember(key) { mutableStateOf(ordered[0].across) }
    var showWin by remember(key) { mutableStateOf(false) }
    var showList by remember(key) { mutableStateOf(false) }

    fun save() {
        store.save(key, letters.joinToString(""), seconds, done)
    }

    fun curEntry(): Entry? =
        puzzle.entryAt(selR, selC, across) ?: puzzle.entryAt(selR, selC, !across)

    fun checkDone() {
        var ok = true
        for (r in 0 until puzzle.rows) {
            for (c in 0 until cols) {
                val sol = puzzle.solution[r][c]
                if (sol != '.' && letters[r * cols + c] != sol) ok = false
            }
        }
        if (ok) {
            done = true
            showWin = true
        }
    }

    fun tap(r: Int, c: Int) {
        if (puzzle.solution[r][c] == '.') return
        if (r == selR && c == selC) {
            if (puzzle.entryAt(r, c, !across) != null) across = !across
        } else {
            selR = r
            selC = c
            if (puzzle.entryAt(r, c, across) == null) across = !across
        }
    }

    fun goTo(e: Entry) {
        across = e.across
        val cs = e.cells()
        val t = cs.firstOrNull { letters[it.first * cols + it.second] == '.' } ?: cs[0]
        selR = t.first
        selC = t.second
    }

    fun step(d: Int) {
        val e = curEntry() ?: return
        val i = ordered.indexOf(e)
        goTo(ordered[(i + d + ordered.size) % ordered.size])
    }

    fun type(ch: Char) {
        if (done) return
        val idx = selR * cols + selC
        letters[idx] = ch
        wrong.remove(idx)
        val e = curEntry()
        if (e != null) {
            across = e.across
            val nr = selR + (if (e.across) 0 else 1)
            val nc = selC + (if (e.across) 1 else 0)
            if (e.contains(nr, nc)) {
                selR = nr
                selC = nc
            }
        }
        checkDone()
        save()
    }

    fun back() {
        if (done) return
        val idx = selR * cols + selC
        if (letters[idx] != '.') {
            letters[idx] = '.'
            wrong.remove(idx)
        } else {
            val e = curEntry()
            if (e != null) {
                val pr = selR - (if (e.across) 0 else 1)
                val pc = selC - (if (e.across) 1 else 0)
                if (e.contains(pr, pc)) {
                    selR = pr
                    selC = pc
                    letters[pr * cols + pc] = '.'
                    wrong.remove(pr * cols + pc)
                }
            }
        }
        save()
    }

    fun check() {
        if (done) return
        wrong.clear()
        for (r in 0 until puzzle.rows) {
            for (c in 0 until cols) {
                val idx = r * cols + c
                val sol = puzzle.solution[r][c]
                if (sol != '.' && letters[idx] != '.' && letters[idx] != sol) wrong.add(idx)
            }
        }
    }

    fun hintCell() {
        if (done) return
        val idx = selR * cols + selC
        letters[idx] = puzzle.solution[selR][selC]
        wrong.remove(idx)
        checkDone()
        save()
    }

    fun hintWord() {
        if (done) return
        val e = curEntry() ?: return
        for (cell in e.cells()) {
            val idx = cell.first * cols + cell.second
            letters[idx] = puzzle.solution[cell.first][cell.second]
            wrong.remove(idx)
        }
        checkDone()
        save()
    }

    LaunchedEffect(key, done) {
        while (!done) {
            delay(1000)
            seconds++
            if (seconds % 5 == 0) save()
        }
    }

    BackHandler {
        save()
        onBack()
    }

    val e = curEntry()
    val inWord = HashSet<Int>()
    e?.cells()?.forEach { inWord.add(it.first * cols + it.second) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            RoundBtn("‹", true) {
                save()
                onBack()
            }
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp)
            ) {
                Text(
                    Generator.LEVELS[level].name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = C.navy
                )
                Text(dayLabel(day), fontSize = 12.sp, color = C.primary)
            }
            Text(fmt(seconds), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = C.navy)
            Spacer(Modifier.size(10.dp))
            Pill("Pistas", Color.White, C.primary) { showList = true }
        }
        Spacer(Modifier.height(10.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .shadow(2.dp, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundBtn("‹", true) { step(-1) }
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp)
            ) {
                if (e != null) {
                    Text(
                        e.num.toString() + " " + (if (e.across) "Horizontal" else "Vertical"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = C.primary
                    )
                    Text(e.clue, fontSize = 16.sp, color = C.navy)
                }
            }
            RoundBtn("›", true) { step(1) }
        }
        Spacer(Modifier.height(8.dp))

        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            val cell = minOf(maxWidth / cols, maxHeight / puzzle.rows, 46.dp)
            Column(Modifier.align(Alignment.Center)) {
                for (r in 0 until puzzle.rows) {
                    Row {
                        for (c in 0 until cols) {
                            val idx = r * cols + c
                            val bg = if (r == selR && c == selC) C.sel
                            else if (idx in wrong) C.wrong
                            else if (idx in inWord) C.word
                            else Color.White
                            CellView(cell, puzzle.solution[r][c], letters[idx], puzzle.numbers[r][c], bg) {
                                tap(r, c)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Revisar", C.primary, Color.White, Modifier.weight(1f)) { check() }
            Pill("Pista", C.amber, C.navy, Modifier.weight(1f)) { hintCell() }
            Pill("Palabra", C.coral, Color.White, Modifier.weight(1f)) { hintWord() }
        }
        Spacer(Modifier.height(8.dp))

        val kb = listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            kb.forEachIndexed { i, s ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (i == 1) Spacer(Modifier.weight(0.5f))
                    if (i == 2) Spacer(Modifier.weight(0.75f))
                    s.forEach { ch -> Key(ch.toString(), Modifier.weight(1f)) { type(ch) } }
                    if (i == 1) Spacer(Modifier.weight(0.5f))
                    if (i == 2) {
                        Key("⌫", Modifier.weight(1.5f)) { back() }
                        Spacer(Modifier.weight(0.75f))
                    }
                }
            }
        }
    }

    if (showWin) {
        AlertDialog(
            onDismissRequest = { showWin = false },
            containerColor = Color.White,
            title = { Text("¡Completado!", color = C.navy, fontWeight = FontWeight.Bold) },
            text = { Text("Lo resolviste en " + fmt(seconds), color = C.navy) },
            confirmButton = {
                TextButton(onClick = {
                    save()
                    onBack()
                }) { Text("Volver", color = C.primary) }
            },
            dismissButton = {
                TextButton(onClick = { showWin = false }) { Text("Ver", color = C.primary) }
            }
        )
    }

    if (showList) {
        AlertDialog(
            onDismissRequest = { showList = false },
            containerColor = Color.White,
            title = { Text("Pistas", color = C.navy, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    Modifier
                        .heightIn(max = 400.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text("Horizontales", color = C.primary, fontWeight = FontWeight.Bold)
                    ordered.filter { it.across }.forEach { en ->
                        Text(
                            en.num.toString() + ". " + en.clue,
                            color = C.navy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    goTo(en)
                                    showList = false
                                }
                                .padding(vertical = 6.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Verticales", color = C.primary, fontWeight = FontWeight.Bold)
                    ordered.filter { !it.across }.forEach { en ->
                        Text(
                            en.num.toString() + ". " + en.clue,
                            color = C.navy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    goTo(en)
                                    showList = false
                                }
                                .padding(vertical = 6.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showList = false }) { Text("Cerrar", color = C.primary) }
            }
        )
    }
}
