# Crucigramas

App Android (Kotlin + Jetpack Compose). Genera 3 crucigramas por día (Fácil, Normal, Difícil), sin internet.

## APK con GitHub
1. Subí todo el contenido de esta carpeta a un repositorio de GitHub (rama main).
2. Entrá a la pestaña **Actions** → **Build APK** (corre solo al subir, o con *Run workflow*).
3. Al terminar, descargá **Crucigramas-APK** desde *Artifacts*, descomprimí e instalá `app-debug.apk`.
